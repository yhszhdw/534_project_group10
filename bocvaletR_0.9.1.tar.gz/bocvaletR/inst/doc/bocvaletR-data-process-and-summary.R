## -----------------------------------------------------------------------------
library(bocvaletR)

## -----------------------------------------------------------------------------
library(dplyr)

fx <- boc_series(c("FXUSDCAD", "FXEURCAD"), start_date = "2023-01-01")
head(fx)

## -----------------------------------------------------------------------------
set.seed(42)

fx_sim <- fx %>%
  arrange(series, date) %>%
  group_by(series) %>%
  mutate(
    value_sim = value,
    # randomly set some points to NA to simulate missingness
    value_sim = ifelse(runif(n()) < 0.05, NA_real_, value_sim)
  ) %>%
  ungroup()

fx_sim %>%
  summarise(n = n(), n_missing = sum(is.na(value_sim)))

## -----------------------------------------------------------------------------
fx_locf <- boc_fill_missing(
  data = fx_sim,
  value_col = "value_sim",
  method = "locf",
  order_col = "date",
  group_col = "series",
  new_col = "filled_locf"
)

fx_locf %>% select(date, series, value_sim, filled_locf) %>% head(10)

## -----------------------------------------------------------------------------
fx_linear <- boc_fill_missing(
  data = fx_sim,
  value_col = "value_sim",
  method = "linear",
  order_col = "date",
  group_col = "series",
  new_col = "filled_linear"
)

fx_linear %>% select(date, series, value_sim, filled_linear) %>% head(10)

## -----------------------------------------------------------------------------
fx_index <- boc_normalize(
  data = fx_locf,
  value_col = "filled_locf",
  method = "index",
  index_base = 100,
  group_col = "series",
  new_col = "index_100"
)

fx_index %>% select(date, series, filled_locf, index_100) %>% head(10)

## -----------------------------------------------------------------------------
fx_ret <- boc_percent_change(
  data = fx_locf,
  value_col = "filled_locf",
  periods = 1,
  type = "log",
  order_col = "date",
  group_col = "series",
  new_col = "log_ret"
)

fx_ret %>% select(date, series, filled_locf, log_ret) %>% head(10)

## -----------------------------------------------------------------------------
fx_roll <- boc_rolling_mean(
  data = fx_locf,
  value_col = "filled_locf",
  window = 10,
  order_col = "date",
  group_col = "series",
  new_col = "ma10"
)

fx_roll %>% select(date, series, filled_locf, ma10) %>% head(10)

## -----------------------------------------------------------------------------
summ <- boc_summary(
  data = fx_sim,
  value_col = "value_sim",
  order_col = "date",
  group_col = "series"
)

summ

## -----------------------------------------------------------------------------
acf_tbl <- boc_autocorr(
  data = fx_locf,
  value_col = "filled_locf",
  lag_max = 10,
  group_col = "series"
)

head(acf_tbl)

## -----------------------------------------------------------------------------
cor_mat <- boc_correlation(
  data = fx_locf %>% dplyr::select(date, series, value = filled_locf),
  value_col = "value"
)
cor_mat

